﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Jsonzai
{
	public class JsonParser
	{
		static Dictionary<Type,List<PropertyInfo>> properties = new Dictionary<Type,List<PropertyInfo>>();
        static object[] attr;

        static void Cache(Type klass)
		{
			properties.Add(klass, klass.GetProperties().ToList());
		}
		static readonly Type[] PARSE_ARGUMENTS_TYPES = { typeof(string) };

		public static object Parse(String source, Type klass)
		{
			return Parse(new JsonTokens(source), klass);
		}

		static object Parse(JsonTokens tokens, Type klass) {
			switch (tokens.Current) {
				case JsonTokens.OBJECT_OPEN:
					return ParseObject(tokens, klass);
				case JsonTokens.ARRAY_OPEN:
					return ParseArray(tokens, klass);
				case JsonTokens.DOUBLE_QUOTES:
					return ParseString(tokens);
				default:
					return ParsePrimitive(tokens, klass);
			}
		}

		private static string ParseString(JsonTokens tokens)
		{
			tokens.Pop(JsonTokens.DOUBLE_QUOTES); // Discard double quotes "
			return tokens.PopWordFinishedWith(JsonTokens.DOUBLE_QUOTES);
		}

        private static object ParsePrimitive(JsonTokens tokens, Type klass)
        {

            string word = tokens.popWordPrimitive();
            if (attr!= null && attr.Length != 0 && attr[0].GetType().Name.Equals("JsonConvertAttribute"))
            {
                attr = null;
                return klass.GetMethod("Parse", new Type[] { typeof(String) }).Invoke(null, new object[] { word });
            }
            else if (!klass.IsPrimitive || typeof(string).IsAssignableFrom(klass))
				if (word.ToLower().Equals("null"))
					return null;
				else if (typeof(string).IsAssignableFrom(klass)) return word;
				else
					throw new InvalidOperationException("Looking for a primitive but requires instance of " + klass);
			return klass.GetMethod("Parse", new Type[] { typeof(String), typeof(IFormatProvider) }).Invoke(null, new object[] { word, CultureInfo.InvariantCulture });
			
		}

		private static object ParseObject(JsonTokens tokens, Type klass)
		{
			tokens.Pop(JsonTokens.OBJECT_OPEN); // Discard bracket { OBJECT_OPEN
			object target = Activator.CreateInstance(klass);
			return FillObject(tokens, target);
		}

		private static object FillObject(JsonTokens tokens, object target)
		{
		   Type klass = target.GetType();
		   if(!properties.ContainsKey(klass)) Cache(klass);            
		   while (tokens.Current != JsonTokens.OBJECT_END)
		   {                               
				string propName = tokens.PopWordFinishedWith(JsonTokens.COLON);
				foreach (PropertyInfo info in properties[klass])
				{
					object[] attrs = info.GetCustomAttributes(typeof(JsonPropertyAttribute), false);
                    attr = info.GetCustomAttributes(typeof(JsonConvertAttribute), false);
					if (propName.Equals(info.Name))
					{
                        if (attr.Length != 0)
                        {
                            foreach(JsonConvertAttribute jca in attr)
                            {
                                object val = Parse(tokens, jca.klass);
                                info.SetValue(target, val);
                            }
                        }
						else SetValue(info, tokens, target);
						break;
					}                    
					if (attrs.Length != 0)
					{                       
						foreach (JsonPropertyAttribute a in attrs)
						{
							if (a.PropertyName.Equals(propName))
							{
								SetValue(info, tokens, target);                            
								break;
							}
						}                
					}                                        
                }                
				tokens.Trim();
				if (tokens.Current != JsonTokens.OBJECT_END){
					tokens.Pop(JsonTokens.COMMA);
				}
			}
			tokens.Pop(JsonTokens.OBJECT_END); // Discard bracket } OBJECT_END
			return target;
		}

		private static void SetValue(PropertyInfo info, JsonTokens tokens, object target)
		{
			object val;
			if (info.PropertyType.IsArray)
				val = Parse(tokens, info.PropertyType.GetElementType());
			else val = Parse(tokens, info.PropertyType);
			info.SetValue(target, val);
		}

		private static object ParseArray(JsonTokens tokens, Type klass)
		{
			ArrayList list = new ArrayList();
			tokens.Pop(JsonTokens.ARRAY_OPEN); // Discard square brackets [ ARRAY_OPEN
			while (tokens.Current != JsonTokens.ARRAY_END)
			{
				list.Add(Parse(tokens,klass));
				if (tokens.Current != JsonTokens.ARRAY_END)
				{
					tokens.Pop(JsonTokens.COMMA);
					tokens.Trim();
				}

			}
			tokens.Pop(JsonTokens.ARRAY_END); // Discard square bracket ] ARRAY_END
			return list.ToArray(klass);
		}
	}
}
