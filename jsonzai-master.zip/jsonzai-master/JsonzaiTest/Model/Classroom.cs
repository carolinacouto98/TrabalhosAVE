﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jsonzai.Test.Model
{
    class Classroom
    {
        public Classroom()
        {
        }
        [JsonConvert(typeof(JsonToDateTime))] public DateTime DueDate { get; set; }
        public string Class { get; set; }
        public Student[] Student { get; set; }
    }
}
