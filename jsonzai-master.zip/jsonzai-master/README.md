Enunciados dos trabalhos de AVE no semestre de inverno  2019/20

* 05 Outubro: [Trabalho 1 - entrega **22 de Outubro**](trabalho1.md)
* 21 Outubro: Trabalho 2 - entrega **11 de Novembro**
* 22 Novembr: Trabalho 3 - entrega **16 de Dezembro**
